import React, { useState } from 'react';
import './App.css';

function Lista() {
  const [tareas, setTareas] = useState([]);
  const [nuevaTarea, setNuevaTarea] = useState('');

  const handleInputChange = (e) => setNuevaTarea(e.target.value);

  const agregarTarea = () => {
    if (!nuevaTarea.trim()) return;
    setTareas([...tareas, { texto: nuevaTarea, completada: false }]);
    setNuevaTarea('');
  };

  const toggleTareaCompletada = (index) => {
    setTareas(tareas.map((tarea, i) => i === index
      ? { ...tarea, completada: !tarea.completada }
      : tarea
    ));
  };

  return (
    <div className='lista'>
      <h1>Lista de Tareas</h1>
      <input 
        type="text" 
        value={nuevaTarea} 
        onChange={handleInputChange} 
        placeholder="Agregar nueva tarea" 
      />
      <button onClick={agregarTarea}>Agregar</button>
      
      <ul>
        {tareas.map((tarea, index) => (
          <li key={index} style={{ textDecoration: tarea.completada ? 'line-through' : 'none' }}>
            <input 
              type="checkbox" 
              checked={tarea.completada} 
              onChange={() => toggleTareaCompletada(index)} 
            />
            {tarea.texto}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default Lista;
