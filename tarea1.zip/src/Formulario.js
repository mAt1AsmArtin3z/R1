import React, { useState } from 'react';
import './App.css';

function Formulario() {
  // Estado para almacenar el nombre del usuario
  const [nombre, setNombre] = useState('');
  // Estado para controlar si el mensaje de bienvenida debe mostrarse
  const [mostrarMensaje, setMostrarMensaje] = useState(false);

  // Manejar el cambio en el campo de entrada
  const handleInputChange = (e) => {
    setNombre(e.target.value);
  };

  // Manejar el envío del formulario
  const handleSubmit = (e) => {
    e.preventDefault(); // Evitar que la página se recargue
    setMostrarMensaje(true); // Mostrar el mensaje de bienvenida
  };

  return (
    <div className='formulario'>
      <h1>Formulario de Bienvenida</h1>
      <form onSubmit={handleSubmit}>
        <label>
          Nombre:
          <input 
            type="text" 
            value={nombre} 
            onChange={handleInputChange} 
            placeholder="Introduce tu nombre" 
          />
        </label>
        <button type="submit">Enviar</button>
      </form>
      {mostrarMensaje && <p>¡Bienvenido, {nombre}!</p>}
    </div>
  );
}

export default Formulario;
