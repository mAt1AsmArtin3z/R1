import './App.css';
import React, { useState } from 'react';

function Contador() {
    const [contador, setContador] = useState(0);

    const agregar = () =>{
        setContador(contador + 1);
    } 
    const quitar = () =>{
        setContador(contador - 1);
    } 

    
    return(
        <div className='contador'>
            <h1>contador</h1>
            <h3>{contador}</h3>
            <button onClick={agregar}>sumame papi</button>
            <button onClick={quitar}>bro wtf?</button>
        </div>


    );
}

export default Contador;