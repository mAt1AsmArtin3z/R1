import './App'

const Nombre = 'Pedro';
const Apellido = 'Bolanios';
const Profesion = 'Ingeniero Aeronautico';
const imageUrl = 'https://i0.wp.com/www.elramovolador.com/wp-content/uploads/2020/01/preboda_en_pals_costa_brava-24.jpg?fit=1500%2C1000&ssl=1';
function Tarjeta() {
    return(
    <div className= 'contenedor'>
    <div className='tarjeta'>
    <h1>info: {Nombre} {Apellido} {Profesion}</h1>
    <img src={imageUrl} alt="Imagen descriptiva" />
    </div>
    </div>

    );
}

export default Tarjeta;